(function() {
  'use strict';

  angular
    .module('infi-cursos')
    .service('Cases', Cases);

    /** @ngInject */
    function Cases(Game){
      var cases = this;

    }

})();
