(function() {
  'use strict';

  angular
    .module('infi-cursos')
    .service('Sprites', Sprites);

    /** @ngInject */
    function Sprites($http){
      var sprites = this;

    }
})();
